import { FilterColumnsPipe } from './filter-columns.pipe';

describe('FilterColumnsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterColumnsPipe();
    expect(pipe).toBeTruthy();
  });
});
